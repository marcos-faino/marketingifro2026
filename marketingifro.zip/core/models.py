from django.db import models
from stdimage import StdImageField


class Base(models.Model):
    criado = models.DateTimeField(auto_now_add=True)
    atualizado = models.DateTimeField(auto_now=True)
    ativo = models.BooleanField(default=True)

    class Meta:
        abstract = True

class Servicos(Base):
    imagem = StdImageField(upload_to='servicos',
                           variations={'thumb': {'width': 471,
                                                 'height': 216,
                                                 'crop': True}})
    icone = models.CharField(max_length=80)
    nome = models.CharField(max_length=150)
    descricao = models.TextField()

